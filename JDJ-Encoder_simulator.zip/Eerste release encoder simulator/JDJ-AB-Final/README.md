# rotaryPulserInt
rotaryPulser based on ATmega328 using Timer1 interrupt

uses:

<pre>
https://github.com/Chris--A/Keypad
https://github.com/fdebrabander/Arduino-LiquidCrystal-I2C-library
</pre>

## Optinal compile options

none
<HR>

<center><img src="./images/4x4-button-keypad.png"</img></center>

<center><img src="./images/AB10kHz.png"</img></center>

